/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  ActivityIndicator //
} from 'react-native';


export default class myapp extends Component {
 constructor(props){
    super(props);

    this.state = {
        id:false
    }

 }
  render() {
      const content = this.state.id?<ActivityIndicator size='larger'/> : 
      <View >
          <Text color='white'>hi</Text>
          </View>;
    return (
        <View style={styles.container}>
         
              {content}
          
       </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
		flex: 1,
    backgroundColor: 'black',
	},
  
});
AppRegistry.registerComponent('myapp', () => myapp);
