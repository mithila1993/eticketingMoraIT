import React, { Component } from 'react';
import {AppRegistry, View,Text ,StyleSheet} from 'react-native';
export default class Splash extends Component {
	render(){
		return(
				<View style={styles.wrapper}>
					<View style={styles.titleWrapper}>
					<Text style={styles.title}>Oracle App!</Text>
					</View>
					<View>
					<Text style={styles.subtitle}>Powered by react-native</Text>
					</View>
				</View>
			);
	}

}
const styles = StyleSheet.create( {
	wrapper: {
		backgroundColor: '#1103a8',
		flex:1 ,
		 justifyContent:'center' ,
		  alignItems:'center'
	},
	title: {
		color: 'white',
		fontSize: 40,
		fontWeight: 'bold'
	},
	subtitle: {
		color: 'white',
		fontWeight: '400',

	},
	titleWrapper: {
		justifyContent: 'center',
		flex:1
	}

});
AppRegistry.registerComponent('Splash', () => Splash);